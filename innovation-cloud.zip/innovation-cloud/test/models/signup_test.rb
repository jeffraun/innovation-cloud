require 'test_helper'

class SignupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
