class PagesController < ApplicationController
  def thanks
  end
end
