class SignupsController < ApplicationController
  def new
    @signup = Signup.new
  end

  def create
    @new = Signup.new(signup_params)
    if @Signup.submit
      redirect_to '/thanks'
    else
      render 'new'
    end
  end

  private

  def signup_params
    params.require(:signup).permit(:email)
  end

end
